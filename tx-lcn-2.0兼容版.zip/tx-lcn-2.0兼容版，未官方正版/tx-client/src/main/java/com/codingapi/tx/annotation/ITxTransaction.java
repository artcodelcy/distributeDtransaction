package com.codingapi.tx.annotation;

/**
 * create by lorne on 2018/1/25
 */
public interface ITxTransaction {
}
