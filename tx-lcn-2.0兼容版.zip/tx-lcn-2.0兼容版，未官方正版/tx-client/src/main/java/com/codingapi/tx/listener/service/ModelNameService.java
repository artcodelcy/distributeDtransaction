package com.codingapi.tx.listener.service;

/**
 * Created by lorne on 2017/7/12.
 */
public interface ModelNameService {

    String getModelName();

    String getUniqueKey();

    String getIpAddress();
}
